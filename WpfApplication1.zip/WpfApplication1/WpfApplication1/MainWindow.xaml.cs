﻿
using System;
using System.Windows.Controls;
using LiveCharts;
using LiveCharts.Wpf;
using System.Collections.ObjectModel;
using System.Windows.Media;
using System.Data;

namespace WpfApplication1
    {
        public partial class MainWindow : UserControl
        {
        private SeriesCollection _listSerie  = new SeriesCollection
            {
                new PieSeries
                {
                    Title = "Maria",
                    Values = new ChartValues<double> {3},
                    PushOut = 15,
                    DataLabels = true,
                 
                },
                new PieSeries
                {
                    Title = "Charles",
                    Values = new ChartValues<double> {4},
                    DataLabels = true,
                    //LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "Frida",
                    Values = new ChartValues<double> {6},
                    DataLabels = true,
                  //  LabelPoint = labelPoint
                },
                new PieSeries
                {
                    Title = "Frederic",
                    Values = new ChartValues<double> {2},
                    DataLabels = true,
                    //LabelPoint = labelPoint
                }
            };

        public MainWindow()
            {
                InitializeComponent();
            //listSerie.Add(
            //    new PieSeries { Title = "ddd", Fill = Brushes.Red, LabelPoint = PointLabel, Values = new ChartValues<double> { 12.54 , 544 , 555} }
            //     );
            //listSerie.Add(
            //    new PieSeries { Title = "BAD", Fill = Brushes.Bisque, StrokeThickness = 0,LabelPoint = PointLabel , Values = new ChartValues<double> { 25 } }
            //     );
            //listSerie.Add(
            //    new PieSeries { Title = "BAddD", Fill = Brushes.Black, StrokeThickness = 0,LabelPoint= PointLabel , Values = new ChartValues<double> { 25 } }
            //     );
            PointLabel = chartPoint =>
                    string.Format("{0} ({1:P})", chartPoint.Y, chartPoint.Participation);
           
                DataContext = this;
            Func<ChartPoint, string> labelPoint = chartPoint =>
        string.Format("{0} ({1:P})", chartPoint.Y, chartPoint.Participation);

           

           
        }
        public SeriesCollection listSerie {
            get { return _listSerie; }
            set
            {
                _listSerie = value;
            }
             } 
           
            public Func<ChartPoint, string> PointLabel { get; set; }

            private void Chart_OnDataClick(object sender, ChartPoint chartpoint)
            {
                var chart = (LiveCharts.Wpf.PieChart)chartpoint.ChartView;

                //clear selected slice.
                foreach (PieSeries series in chart.Series)
                    series.PushOut = 0;

                var selectedSeries = (PieSeries)chartpoint.SeriesView;
                selectedSeries.PushOut = 8;
            }
        }
    }

